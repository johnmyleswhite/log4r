`logfile<-` <-
function(x, value)
{
  UseMethod('logfile<-', x)
}

