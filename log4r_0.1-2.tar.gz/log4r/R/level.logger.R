`level.logger` <-
function(x)
{
  return(x[['level']])
}
