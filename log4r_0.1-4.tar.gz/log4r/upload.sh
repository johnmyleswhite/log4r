#!/bin/bash

ftp ftp://cran.r-project.org
# cd incoming
# bin
# put log4r_*.tar.gz
# exit
