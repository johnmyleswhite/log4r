`logformat<-` <-
function(x, value)
{
  UseMethod('logformat<-', x)
}
