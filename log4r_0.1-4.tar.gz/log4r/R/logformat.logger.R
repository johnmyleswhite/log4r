`logformat.logger` <-
function(x)
{
  return(x[['logformat']])
}
