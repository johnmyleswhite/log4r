`logfile.logger` <-
function(x)
{
  return(x[['logfile']])
}
