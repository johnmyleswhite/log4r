#!/bin/bash

rm log4r_*.tar.gz
rm -rf log4r.Rcheck
R CMD BUILD .
R CMD CHECK log4r_*.tar.gz
R CMD INSTALL log4r_*.tar.gz
