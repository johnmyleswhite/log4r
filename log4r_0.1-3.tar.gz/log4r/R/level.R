`level` <-
function(x)
{
  UseMethod('level', x)
}
