`logfile` <-
function(x)
{
  UseMethod('logfile', x)
}
