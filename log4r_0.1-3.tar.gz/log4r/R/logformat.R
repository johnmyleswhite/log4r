`logformat` <-
function(x)
{
  UseMethod('logformat', x)
}
